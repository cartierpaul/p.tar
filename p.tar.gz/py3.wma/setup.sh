#!/bin/bash

# Check if the required interfaces and bridge already exist and remove them if necessary
ip link show eth0 >/dev/null 2>&1 && ip link del eth0
ip link show host-enp3s0 >/dev/null 2>&1 && ip link del host-enp3s0
ip link show vlan.5 >/dev/null 2>&1 && ip link del vlan.5
ip link show vlan.10 >/dev/null 2>&1 && ip link del vlan.10
ip link show br0 >/dev/null 2>&1 && ip link del br0

# Create the peer virtual device
ip link add eth0 type veth peer name host-enp3s0
ip link set host-enp3s0 up
ip link set eth0 up
ip addr add 192.168.137.137/24 dev host-enp3s0

# Add two VLANs on top of it
ip link add link host-enp3s0 name vlan.5 type vlan id 5
ip link add link vlan.5 name vlan.10 type vlan id 10
ip addr add 192.168.147.137/24 dev vlan.10

# Check if the bridge already exists and remove it if necessary
ip link show br0 >/dev/null 2>&1 && ip link del br0

# Create a bridge to enable hooks
ip link add name br0 type bridge
ip link set dev br0 up
ip link set eth0 master br0
ip addr add 192.168.157.137/24 dev br0
ip link set vlan.5 master br0
ip link set vlan.10 master br0

# Show the network setup status
echo "Network setup successfully completed:"
echo "Virtual Interface eth0 created with IP: 192.168.137.137/24"
echo "VLAN Interface vlan.5 created with IP: 192.168.147.137/24"
echo "VLAN Interface vlan.10 created and added to VLAN ID 10"
echo "Bridge br0 created and configured with IP: 192.168.157.137/24"
